using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Timer : MonoBehaviour
{
    private static Timer instance;

    private float elapsedTime = 0f;
    private bool timerRunning = false;

    private TextMeshProUGUI timerText;

    private int previousSceneIndex = -1;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void OnDestroy()
    {
        if (instance == this)
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        int currentSceneIndex = scene.buildIndex;

        GameObject textObj = GameObject.FindGameObjectWithTag("TimerText");
        timerText = textObj != null ? textObj.GetComponent<TextMeshProUGUI>() : null;

        // <-- �������� ���� ���� ����
        if (currentSceneIndex == 1)
        {
            if (timerText != null)
                timerText.gameObject.SetActive(false);
        }
        else
        {
            if (timerText != null)
                timerText.gameObject.SetActive(true);
        }

        // ����� ��� ��������� ������:
        if (previousSceneIndex == 3 && currentSceneIndex == 0)
        {
            elapsedTime = 0f;
            timerRunning = false;
        }
        else if (previousSceneIndex == 0 && currentSceneIndex == 1)
        {
            elapsedTime = 0f;
            timerRunning = true;
        }
        else if (currentSceneIndex == 1 || currentSceneIndex == 2 || currentSceneIndex == 3)
        {
            timerRunning = true;
        }
        else
        {
            timerRunning = false;
        }

        previousSceneIndex = currentSceneIndex;
    }


    void Update()
    {
        if (timerRunning)
        {
            elapsedTime += Time.deltaTime;

            if (timerText != null)
            {
                int minutes = Mathf.FloorToInt(elapsedTime / 60);
                int seconds = Mathf.FloorToInt(elapsedTime % 60);
                timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
            }
        }
        else
        {
            if (timerText != null)
            {
                timerText.text = "00:00";
            }
        }
    }
}
