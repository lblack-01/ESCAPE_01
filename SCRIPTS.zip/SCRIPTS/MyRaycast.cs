using TMPro;
using UnityEngine;

public class MyRaycast : MonoBehaviour
{
    public GameObject text;
    //public GameObject img;

    void Start()
    {
        
    }

    void Update()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //Camera.main.ScreenPointToRay(Input.mousePosition); 
        //Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0)); // Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;


        if ((Physics.Raycast(ray, out hit, 100)) && (Input.GetMouseButtonDown(0)))
        {
            Debug.DrawLine(ray.origin, hit.point, Color.red);

            if (hit.collider.tag == "my")
            {
                text.SetActive(true);
                text.GetComponent<TMPro.TextMeshProUGUI>().text = hit.collider.gameObject.name;
                //img.SetActive(true);
            }
            else
            {
                text.SetActive(false);
                //img.SetActive(false);
            }
        }
    }
}
