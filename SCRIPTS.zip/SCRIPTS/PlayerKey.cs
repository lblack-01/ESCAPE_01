using UnityEngine;
using TMPro;

public class PlayerKey : MonoBehaviour
{
    [Header("Interaction Settings")]
    public KeyCode interactionKey = KeyCode.F;
    public float interactionDistance = 3f;
    public GameObject doorToRemove;

    [Header("UI Settings")]
    public GameObject interactionText;
    public float maxDetectionDistance = 10f;

    private bool hasKey = false;
    private GameObject lastHitObject;

    void Update()
    {
        HandleTextDisplay();

        if (Input.GetKeyDown(interactionKey) && !hasKey)
        {
            TryPickUpKey();
        }
    }

    private void HandleTextDisplay()
    {
        if (interactionText == null || hasKey) return;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        bool shouldShowText = false;

        if (Physics.Raycast(ray, out hit, maxDetectionDistance))
        {
            if (hit.collider != null && hit.collider.CompareTag("Key"))
            {
                shouldShowText = true;
                lastHitObject = hit.collider.gameObject;
            }
        }

        interactionText.SetActive(shouldShowText);
    }

    private void TryPickUpKey()
    {
        if (lastHitObject == null) return;

        float distance = Vector3.Distance(transform.position, lastHitObject.transform.position);
        if (distance <= interactionDistance)
        {
            hasKey = true;
            Destroy(lastHitObject);
            interactionText.SetActive(false);

            if (doorToRemove != null)
                Destroy(doorToRemove);
        }
    }
}