using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class FakeTimer_2 : MonoBehaviour
{
    [SerializeField] TextMeshPro FakeTimerS;
    float elapsedTime;
    float speedMultiplier = 0.3f;

    void Update()
    {
        elapsedTime += Time.deltaTime * speedMultiplier;
        int minutes = Mathf.FloorToInt(elapsedTime / 20);
        int seconds = Mathf.FloorToInt(elapsedTime % 20);
        FakeTimerS.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}