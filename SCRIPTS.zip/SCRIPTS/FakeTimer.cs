using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class FakeTimer : MonoBehaviour
{
    [SerializeField] TextMeshPro FakeTimerF;
    float elapsedTime;
    float speedMultiplier = 8f;

    void Update()
    {
        elapsedTime += Time.deltaTime * speedMultiplier;
        int minutes = Mathf.FloorToInt(elapsedTime / 90);
        int seconds = Mathf.FloorToInt(elapsedTime % 20);
        FakeTimerF.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}