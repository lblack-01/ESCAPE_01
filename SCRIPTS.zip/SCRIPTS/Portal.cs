using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal : MonoBehaviour

{
   
    public void OnTriggerEnter(Collider other)
    {
        SceneManager.LoadScene(2);

    }
}


