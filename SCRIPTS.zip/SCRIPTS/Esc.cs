using UnityEngine;
using UnityEngine.SceneManagement;

public class Esc : MonoBehaviour
{
    void Update()
    {
        if (Input.GetKey("escape"))
        {
            SceneManager.LoadScene(0);
        }
    }
}
